-- Global SQLite — illustrative first migration. Better Auth tables generated separately.
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;
CREATE TABLE IF NOT EXISTS workspaces (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL CHECK (status IN ('draft','discovering','configured','verifying','active','suspended','exporting','archived','restore_pending','restore_blocked')),
  config_sha TEXT NOT NULL,
  created_at_ms INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS jobs (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id),
  status TEXT NOT NULL,
  operation TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  config_digest TEXT NOT NULL,
  attempt_no INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 0,
  created_at_ms INTEGER NOT NULL,
  UNIQUE(workspace_id, idempotency_key)
);
CREATE TABLE IF NOT EXISTS resource_locks (
  resource_key TEXT PRIMARY KEY,
  owner_attempt_id TEXT NOT NULL,
  fence_token INTEGER NOT NULL CHECK(fence_token >= 1),
  expires_at_ms INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS job_attempts (
  id TEXT PRIMARY KEY,
  job_id TEXT NOT NULL REFERENCES jobs(id),
  runner_id TEXT NOT NULL,
  attempt_no INTEGER NOT NULL,
  lease_expires_at_ms INTEGER NOT NULL,
  fence_token INTEGER NOT NULL,
  status TEXT NOT NULL,
  UNIQUE(job_id, attempt_no)
);
CREATE TABLE IF NOT EXISTS approval_requests (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id),
  request_digest TEXT NOT NULL,
  operation TEXT NOT NULL,
  target TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('pending','approved','rejected','expired','revoked')),
  expires_at_ms INTEGER NOT NULL,
  policy_digest TEXT NOT NULL,
  decision_actor_id TEXT,
  decision_text TEXT,
  consumed_at_ms INTEGER
);
CREATE TABLE IF NOT EXISTS audit_events (
  event_id TEXT PRIMARY KEY,
  aggregate_id TEXT NOT NULL,
  aggregate_seq INTEGER NOT NULL,
  occurred_at_ms INTEGER NOT NULL,
  payload_json TEXT NOT NULL,
  payload_sha256 TEXT NOT NULL,
  UNIQUE(aggregate_id, aggregate_seq)
);
CREATE TABLE IF NOT EXISTS global_outbox (
  id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  aggregate_id TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  occurred_at_ms INTEGER NOT NULL,
  delivered_at_ms INTEGER
);
CREATE INDEX IF NOT EXISTS jobs_by_status ON jobs(status, created_at_ms);
CREATE INDEX IF NOT EXISTS approval_by_status ON approval_requests(status, expires_at_ms);
CREATE INDEX IF NOT EXISTS outbox_undelivered ON global_outbox(delivered_at_ms, occurred_at_ms);
