-- Workspace SQLite — illustrative first migration. Mastra-managed tables are separate.
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;
CREATE TABLE IF NOT EXISTS tasks (
  id TEXT PRIMARY KEY,
  status TEXT NOT NULL,
  title TEXT NOT NULL,
  acceptance_json TEXT NOT NULL DEFAULT '[]',
  version INTEGER NOT NULL DEFAULT 0,
  created_at_ms INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS workflow_runs (
  id TEXT PRIMARY KEY,
  definition_digest TEXT NOT NULL,
  mastra_workflow_id TEXT NOT NULL,
  current_state TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  finalized_at_ms INTEGER
);
CREATE TABLE IF NOT EXISTS evidence_bundles (
  id TEXT PRIMARY KEY,
  task_id TEXT REFERENCES tasks(id),
  status TEXT NOT NULL CHECK(status IN ('assembling','submitted','verified','rejected','incomplete')),
  manifest_sha256 TEXT NOT NULL,
  created_at_ms INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS tool_observations (
  id TEXT PRIMARY KEY,
  run_id TEXT NOT NULL,
  signature TEXT NOT NULL,
  outcome TEXT NOT NULL,
  observed_at_ms INTEGER NOT NULL,
  UNIQUE(run_id, signature)
);
CREATE TABLE IF NOT EXISTS tool_candidates (
  id TEXT PRIMARY KEY,
  signature TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL,
  source_count INTEGER NOT NULL,
  created_at_ms INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS workspace_outbox (
  id TEXT PRIMARY KEY,
  event_type TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  occurred_at_ms INTEGER NOT NULL,
  delivered_at_ms INTEGER
);
CREATE TABLE IF NOT EXISTS global_event_inbox (
  event_id TEXT PRIMARY KEY,
  applied_at_ms INTEGER NOT NULL
);
