---
id: k8s.list-pods
version: 1.0.0
risk: read-only
capabilities: [kubernetes.read]
timeoutSeconds: 30
inputSchema: ./input.schema.json
outputSchema: ./output.schema.json
owner: platform
maxOutputBytes: 1048576
---

# List Kubernetes pods

Read pod status in an explicitly approved Kubernetes context and namespace.

- Inputs: context, namespace.
- Output: kubectl JSON on stdout; diagnostic stderr on failure.
- Never print credentials or switch contexts implicitly.
- Runtime MUST separately restrict kubeconfig and Kubernetes RBAC.
