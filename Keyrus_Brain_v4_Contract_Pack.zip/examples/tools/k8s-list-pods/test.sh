#!/usr/bin/env bash
set -Eeuo pipefail
bash -n "$(dirname "$0")/run.sh"
if "$(dirname "$0")/run.sh" >/dev/null 2>&1; then
  echo 'Expected argument validation failure' >&2
  exit 1
fi
# Real integration tests run with a permitted fixture context and mocked kubectl.
