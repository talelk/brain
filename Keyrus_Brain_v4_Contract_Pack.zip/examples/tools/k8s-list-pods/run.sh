#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $# -ne 2 ]]; then
  echo 'Usage: run.sh KUBE_CONTEXT NAMESPACE' >&2
  exit 64
fi
ctx="$1"
ns="$2"
re='^[A-Za-z0-9][A-Za-z0-9._-]*$'
if [[ ! "$ctx" =~ $re || ! "$ns" =~ $re ]]; then
  echo 'Invalid context or namespace' >&2
  exit 64
fi
exec kubectl --context "$ctx" --namespace "$ns" --request-timeout=15s get pods --output=json
