# Boundary rules (implementation checklist)

1. Git is the only editable authority for long-lived configuration. SQLite contains operational decisions and references to the effective config digest.
2. Better Auth authenticates; Governor authorizes exact actions; Mastra only suspends and resumes workflows.
3. All clients (web, mobile, CLI, MCP) invoke the same command/query handlers. No direct DB mutations.
4. Workspace data never leaks to a different workspace through SQL paths, artifacts, memory scopes or tool/runner credentials.
5. The global control DB owns job/lease/approval authority. Workspace DB owns business and workflow history.
6. A cross-DB mutation is asynchronous through outbox/inbox with idempotency and consistency watermark, not a pseudo-distributed transaction.
7. Runners cannot access central SQLite files or TencentDB admin keys; privileged tools must be brokered and isolated.
8. Every tool is identified by immutable release digest; scripts authored by an agent are quarantined until independent verification.
9. A worktree lock and p-queue do not constitute a distributed lock. The global lease and target-specific fencing/checks remain authoritative.
10. Three independent successful equivalent operations produce one candidate, not an auto-approved global tool.
11. Mastra workflows/steps are loaded from Git-compiled immutable releases and never administered directly through arbitrary public Mastra routes.
12. Memory is knowledge, not permission: a retrieved Skill or Wiki cannot grant executable access.
13. A production approval always binds reviewed action, target, version and expiry; a model's quoted approval is not a human decision.
14. Outcomes after ambiguous external effects are reconciled before retry. "Exactly once" is not assumed.
15. Completion requires a verified evidence bundle; no model-generated DONE state accepted.
