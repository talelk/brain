// contracts/src/contracts.ts — stable Brain DTOs, NOT Mastra/Pi/Claude SDK types.
export type Digest = `sha256:${string}`;
export type ActorKind = 'human' | 'runner' | 'agent' | 'workflow';
export interface ActorContext {
  kind: ActorKind;
  actorId: string;
  organizationId: string;
  workspaceId?: string;
  delegatedBy?: string;
  runId?: string;
  scopes: string[];
  authMethod: 'session' | 'machine-key' | 'delegated-grant';
}
export interface CommandEnvelope<T = unknown> {
  contractVersion: 'brain.command/v1';
  commandId: string;
  commandType: string;
  workspaceId?: string;
  idempotencyKey: string;
  expectedVersion?: number;
  payload: T;
}
export interface CommandReceipt {
  commandId: string;
  accepted: boolean;
  outcome: 'applied' | 'queued' | 'pending-approval' | 'rejected';
  eventId?: string;
  resourceId?: string;
  error?: BrainError;
}
export interface BrainError {code: string; detail: string; retryable: boolean; correlationId?: string}
export interface EngineSessionSpec {
  contractVersion: 'brain.engine/v1';
  workspaceId: string; dispatchId: string; jobId: string; attemptId: string;
  engineId: string; modelId: string; runnerId: string;
  checkoutRef: string; workingDirectory: string; configDigest: string;
  allowedToolReleaseDigests: string[];
  limits: {timeoutMs: number; maxTokens?: number; maxUsd?: number};
  contextArtifactId: string; approvalRefs: string[];
}
export type EngineCapability = 'start'|'events'|'cancel'|'resume'|'steer'|'interactive'|'headless'|'tool-intercept'|'context-fork'|'usage';
export interface EngineEvent {
  contractVersion: 'brain.engine.event/v1';
  eventId: string; sessionId: string; attemptId: string; sequence: number;
  kind: 'session.started'|'session.stopped'|'text'|'tool.proposed'|'tool.result'|'usage'|'artifact'|'human.input.requested'|'error';
  occurredAt: string; payload: unknown;
}
export interface EngineAdapter {
  readonly id: string;
  capabilities(): ReadonlySet<EngineCapability>;
  start(spec: EngineSessionSpec): Promise<{sessionId: string}>;
  events(sessionId: string): AsyncIterable<EngineEvent>;
  cancel(sessionId: string, reason: string): Promise<void>;
  steer?(sessionId: string, message: string): Promise<void>;
  resume?(sessionId: string): Promise<void>;
}
export interface ToolInvocation {
  contractVersion: 'brain.tool/v1';
  invocationId: string; workspaceId: string; dispatchId?: string;
  jobId: string; attemptId: string; toolId: string; releaseDigest: Digest;
  input: Record<string, unknown>; inputDigest: Digest;
  target: {environmentId: string; resourceId: string};
  approvalId?: string; executionGrantId: string;
  idempotencyKey: string; fencingToken: number;
}
export interface ToolReceipt {
  invocationId: string; attemptId: string; fencingToken: number;
  result: 'succeeded'|'failed'|'partial'|'unknown';
  startedAt: string; finishedAt?: string; exitCode?: number;
  stdoutArtifactId?: string; stderrArtifactId?: string;
  evidenceArtifactIds: string[]; effectsObserved: string[];
}
export interface WorkflowEnginePort {
  register(releaseDigest: Digest, definition: unknown): Promise<string>;
  start(workflowId: string, runId: string, input: unknown): Promise<void>;
  resume(runId: string, wakeEventId: string): Promise<void>;
  cancel(runId: string, reason: string): Promise<void>;
  inspect(runId: string): Promise<{status: string; stageIds: string[]}>;
}
export interface MemoryScope {
  organizationId: string; workspaceId?: string; teamId?: string;
  visibility: 'global-approved'|'team'|'workspace'|'private';
}
export interface MemoryQuery {
  contractVersion: 'brain.memory/v1'; queryId: string;
  scope: MemoryScope; agentRole: string; query: string;
  sourceTypes: Array<'chat'|'skill'|'wiki'|'codegraph'>;
  limit: number; maxChars: number;
}
