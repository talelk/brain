import { existsSync, readFileSync, writeFileSync, unlinkSync, mkdirSync, lstatSync } from "node:fs";
import { join } from "node:path";
import { createHash, randomBytes, randomUUID } from "node:crypto";
import { Brain } from "../apps/governor/src/application/brain";
import { collectRelease } from "../apps/cli/src/release";
import { credentialStore } from "../apps/cli/src/credentials";

const dataDir = process.env["BRAIN_DATA_DIR"]!;
const stateFile = join(dataDir, "first-launch.json");
const passwordFile = join(dataDir, "initial-admin-password");
mkdirSync(dataDir, { recursive: true, mode: 0o700 });
const brain = new Brain({ dataDir });
try {
  await brain.auth.ready();
  const existing = brain.store.control.prepare("SELECT id FROM organizations LIMIT 1").get();
  if (existing && !existsSync(stateFile)) { console.log("Existing installation preserved."); }
  else {
    let state: { organizationId: string; workspaceId: string; completed: boolean };
    if (existsSync(stateFile)) state = JSON.parse(readFileSync(stateFile, "utf8"));
    else {
      state = { organizationId: `org-${randomUUID()}`, workspaceId: `ws-${randomUUID()}`, completed: false };
      writeFileSync(stateFile, JSON.stringify(state), { mode: 0o600, flag: "wx" });
    }
    if (!state.completed) {
      if (!existsSync(passwordFile)) writeFileSync(passwordFile, randomBytes(24).toString("base64url"), { mode: 0o600, flag: "wx" });
      const stat = lstatSync(passwordFile);
      if (!stat.isFile() || stat.isSymbolicLink() || (stat.mode & 0o077)) throw new Error("Initial password must be a private regular file");
      const password = readFileSync(passwordFile, "utf8").trim();
      let sessionToken: string;
      if (!existing) {
        const result = await brain.bootstrap({ email: "admin@brain.local", password, name: "My organization", organizationId: state.organizationId }, readFileSync(join(dataDir, "setup.token"), "utf8").trim());
        sessionToken = result.sessionToken;
      } else {
        const account = await brain.auth.bootstrapAccount({ email: "admin@brain.local", password, name: "Administrator" });
        sessionToken = account.token;
      }
      const headers = new Headers({ authorization: `Bearer ${sessionToken}` });
      const identity = await brain.resolveActor(headers);
      if (!brain.store.control.prepare("SELECT 1 FROM workspaces WHERE id=?").get(state.workspaceId)) brain.createWorkspace(identity.actor, { workspaceId: state.workspaceId, slug: "My workspace" });
      const bundle = collectRelease("examples/v1/starter-release");
      bundle.documents = bundle.documents.map((doc) => ({ ...doc, text: doc.text.replaceAll('"org-local"', JSON.stringify(state.organizationId)).replaceAll('"operations"', JSON.stringify(state.workspaceId)).replace('"displayName": "Operations"', '"displayName": "My workspace"') }));
      const { digest } = brain.stageRelease(identity.actor, bundle.documents, `sha256:${createHash("sha256").update(JSON.stringify(bundle)).digest("hex")}`, bundle.scripts, bundle.instructions, bundle.schemas);
      const active = brain.store.control.prepare("SELECT release_digest FROM active_config WHERE organization_id=?").get(state.organizationId) as { release_digest: string } | undefined;
      if (!active) brain.activateRelease(identity.actor, digest, null);
      brain.store.control.prepare("UPDATE user SET name='Administrator' WHERE id=?").run(identity.principalId);
      brain.store.control.prepare("INSERT OR IGNORE INTO brain_initial_password(user_id,password_hash) SELECT userId,password FROM account WHERE userId=? AND providerId='credential'").run(identity.principalId);
      credentialStore(process.env["BRAIN_GOVERNOR_URL"]!, process.env).save(sessionToken);
      state.completed = true;
      writeFileSync(stateFile, JSON.stringify(state), { mode: 0o600 });
      console.log("Created administrator, My workspace, starter workflows and governed tools.");
    }
    const pending = brain.store.control.prepare("SELECT 1 FROM brain_initial_password LIMIT 1").get();
    if (pending && existsSync(passwordFile) && process.stdout.isTTY) console.log(`First sign-in: admin@brain.local\nTemporary password: ${readFileSync(passwordFile, "utf8").trim()}`);
    else if (pending) console.log(`First sign-in: admin@brain.local. Read the temporary password from ${passwordFile} on this host.`);
    else if (existsSync(passwordFile)) unlinkSync(passwordFile);
  }
} finally { brain.close(); }
